public class Inventory {
}
