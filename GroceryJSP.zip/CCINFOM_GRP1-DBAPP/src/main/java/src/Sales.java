public class Sales {
}
